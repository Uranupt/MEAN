var mathlib = require('./mathlib.js')();
console.log(mathlib.add(3,6))
console.log(mathlib.multiply(2,9))
console.log(mathlib.square(6))
console.log(mathlib.random(4,30))
